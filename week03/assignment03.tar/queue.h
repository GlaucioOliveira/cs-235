/***********************************************************************
 * Header:
 *    Array 
 * Summary:
 *    This class contains a queue data structure
 *
 * Author
 *    Br. Helfrich
 ************************************************************************/

#ifndef QUEUE_H
#define QUEUE_H

#include <cassert>  // because I am paranoid
#include <iostream>


// a little helper macro to write debug code
#ifdef NDEBUG
#define Debug(statement)
#else
#define Debug(statement) statement
#endif // !NDEBUG

namespace custom
{

/************************************************
 * queue
 * A class that holds stuff
 ***********************************************/
template <class T>
class queue
{
public:
   // constructors and destructors
    queue() { numPop = 0; numPush = 0; numCapacity = 0; array = NULL; }
   queue(int numCapacity);
   queue(const queue & rhs);
  ~queue() { 
      if (numCapacity > 0 )
      {
            delete[] array;
      }
          
  }
   queue & operator = (const queue & rhs);	//assign
   
   // standard container interfaces
   // queue treats size and max_size the same
   int  size()     const { return numPush - numPop;                 }
   int  max_size() const { return numElements;                 }
   int capacity()  const { return numCapacity; }
   bool  empty()   const { return numElements == 0; }

   void clear() { 
       numElements = 0; 
   }
   
   
   void push(T t) {
       expandArray();

       array[iTail] = t;
       iTail++;   
   }

   void pop() {
       if(iTail - iHead > 0)
        numPop++;
   }

   T back() const {
       if (numElements > 0)
           return array[numElements - 1];
       else
           throw "ERROR: Unable to reference the element from an empty queue";
   }

   T front() const {
       if (numElements > 0)
           return array[0];
       else
           throw "ERROR: Unable to reference the element from an empty queue";
   }

   
   // the various iterator interfaces
   class iterator;
   iterator begin()      { return iterator (array); }
   iterator end();

   // a debug utility to display the queue
   // this gets compiled to nothing if NDEBUG is defined
   void display() const; 
   
private:
   T * array;
   int numElements;
   int numCapacity;
   
   int numPush;
   int numPop;
   
   int iHead;
   
   int iTail;

   void expandArray() {
       //if there is no more space to add another item on the array
       if (numElements + 1 > capacity())
       {
           T* tempArray = NULL;

           if (capacity() > 0)
               numCapacity *= 2;
           else
               numCapacity = 1;

           try
           {
               tempArray = new T[numCapacity];
           }
           catch (std::bad_alloc)
           {
               throw "ERROR: Unable to allocate buffer";
           }
           
           if (numCapacity > 1) {
               for (int i = 0; i < numElements; i++)
                   tempArray[i] = array[i];

               delete[] array;
               array = tempArray;
           }
           else
           {
               array = tempArray;
           }
       }
   }
};

/**************************************************
 * queue ITERATOR
 * An iterator through queue
 *************************************************/
/*
template <class T>
class queue <T> :: iterator
{
public:
   // constructors, destructors, and assignment operator
   iterator()      : p(NULL)      {              }
   iterator(T * p) : p(p)         {              }
   iterator(const iterator & rhs) { *this = rhs; }
   iterator & operator = (const iterator & rhs)
   {
      this->p = rhs.p;
      return *this;
   }

   // equals, not equals operator
   bool operator != (const iterator & rhs) const { return rhs.p != this->p; }
   bool operator == (const iterator & rhs) const { return rhs.p == this->p; }

   // dereference operator
         T & operator * ()       { return *p; }
   const T & operator * () const { return *p; }

   // prefix increment
   iterator & operator ++ ()
   {
      p++;
      return *this;
   }

   // postfix increment
   iterator operator ++ (int postfix)
   {
      iterator tmp(*this);
      p++;
      return tmp;
   }
   
private:
   T * p;
};
*/

/********************************************
 * queue :: END
 * Note that you have to use "typename" before
 * the return value type
 ********************************************/
template <class T>
typename queue <T> :: iterator queue <T> :: end ()
{
   return iterator (array + numElements);
}

/*******************************************
 * queue :: Assignment
 *******************************************/
template <class T>
queue <T> & queue <T> :: operator = (const queue <T> & rhs)
{
   // we can only copy queues of equal size. Vectors are not this way!
   if (numCapacity < rhs.size())
   {
	   //resize(rhs.size());
      //throw "ERROR: Unable to copy queues of different sizes";
       try
       {
           array = NULL;
           delete[] array;

           array = new T[rhs.size()];
           numElements = rhs.numElements;
           numCapacity = rhs.numCapacity;

       }
       catch (std::bad_alloc)
       {
           throw "ERROR: Unable to allocate a new buffer for queue";
       }
   }

   assert(numElements == rhs.numElements);

   for (int i = 0; i < numElements; i++)
      array[i] = rhs.array[i];

   return *this;
}

/*******************************************
 * queue :: COPY CONSTRUCTOR
 *******************************************/
template <class T>
queue <T> :: queue(const queue <T> & rhs) 
{
   assert(rhs.numElements >= 0);
      
   // do nothing if there is nothing to do
   if (rhs.numElements == 0)
   {
      numElements = 0;
      numCapacity = 0;
      array = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      array = new T[rhs.numCapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for queue";
   }
   
   // copy over the capacity
   numElements = rhs.numElements;
   numCapacity = rhs.numCapacity;

   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < numElements; i++)
      array[i] = rhs.array[i];
}

/**********************************************
 * queue : NON-DEFAULT CONSTRUCTOR
 * Preallocate the queue to "capacity"
 **********************************************/
template <class T>
queue <T> :: queue(int numCapacity) 
{
   assert(numElements >= 0);
   
   // do nothing if there is nothing to do.
   // since we can't grow an queue, this is kinda pointless
   if (numCapacity == 0)
   {
      this->numCapacity = 0;
      numElements = 0;

      this->array = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      array = new T[numCapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }

   this->numElements = 0;
   this->numCapacity = numCapacity;
}

/********************************************
 * queue : DISPLAY
 * A debug utility to display the contents of the queue
 *******************************************/
template <class T>
void queue <T> :: display() const
{
#ifndef NDEBUG
   std::cerr << "queue<T>::display()\n";
   std::cerr << "\tnumElements = " << numElements << "\n";
   for (int i = 0; i < numElements; i++)
      std::cerr << "\tarray[" << i << "] = " << array[i] << "\n";
#endif // NDEBUG
}

}; // namespace custom

#endif // queue_H

